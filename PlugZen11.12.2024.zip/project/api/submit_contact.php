<?php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['error' => 'Invalid request method']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

if (!$data) {
    echo json_encode(['error' => 'Invalid data format']);
    exit;
}

try {
    $stmt = $pdo->prepare("
        INSERT INTO contact_messages (name, email, phone, message, created_at)
        VALUES (:name, :email, :phone, :message, NOW())
    ");

    $stmt->execute([
        'name' => $data['name'],
        'email' => $data['email'],
        'phone' => $data['phone'],
        'message' => $data['message']
    ]);

    echo json_encode(['success' => true, 'message' => 'Message sent successfully']);
} catch(PDOException $e) {
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}