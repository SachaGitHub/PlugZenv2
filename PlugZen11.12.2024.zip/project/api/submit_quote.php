<?php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['error' => 'Invalid request method']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

if (!$data) {
    echo json_encode(['error' => 'Invalid data format']);
    exit;
}

try {
    $stmt = $pdo->prepare("
        INSERT INTO quote_requests (
            type,
            vehicle_type,
            property_type,
            name,
            email,
            phone,
            address,
            message,
            created_at
        )
        VALUES (
            :type,
            :vehicle_type,
            :property_type,
            :name,
            :email,
            :phone,
            :address,
            :message,
            NOW()
        )
    ");

    $stmt->execute([
        'type' => $data['type'],
        'vehicle_type' => $data['vehicleType'],
        'property_type' => $data['propertyType'],
        'name' => $data['name'],
        'email' => $data['email'],
        'phone' => $data['phone'],
        'address' => $data['address'],
        'message' => $data['message']
    ]);

    echo json_encode(['success' => true, 'message' => 'Quote request sent successfully']);
} catch(PDOException $e) {
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}