import { useState, useCallback } from 'react';
import { validateEmail, validatePhone, validateRequired } from '../utils/validation';

interface ValidationRules {
  required?: boolean;
  email?: boolean;
  phone?: boolean;
}

interface FormErrors {
  [key: string]: string;
}

export const useForm = <T extends Record<string, any>>(initialState: T, validationRules: Record<keyof T, ValidationRules>) => {
  const [formData, setFormData] = useState<T>(initialState);
  const [errors, setErrors] = useState<FormErrors>({});

  const validate = useCallback(() => {
    const newErrors: FormErrors = {};
    
    Object.keys(validationRules).forEach((field) => {
      const rules = validationRules[field];
      const value = formData[field];

      if (rules.required && !validateRequired(value)) {
        newErrors[field] = 'Ce champ est requis';
      } else if (rules.email && !validateEmail(value)) {
        newErrors[field] = 'Email invalide';
      } else if (rules.phone && !validatePhone(value)) {
        newErrors[field] = 'Numéro de téléphone invalide';
      }
    });

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  }, [formData, validationRules]);

  const handleChange = useCallback((e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  }, [errors]);

  const resetForm = useCallback(() => {
    setFormData(initialState);
    setErrors({});
  }, [initialState]);

  return {
    formData,
    errors,
    handleChange,
    validate,
    resetForm,
    setFormData
  };
};