import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin, Zap } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <Zap className="h-8 w-8 text-green-500" />
              <span className="text-2xl font-bold">PlugZen</span>
            </div>
            <p className="text-gray-400">
              Expert en solutions de recharge pour véhicules électriques.
            </p>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact</h3>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Phone className="h-5 w-5 text-green-500" />
                <span>07 81 70 28 73</span>
              </div>
              <div className="flex items-center space-x-2">
                <Mail className="h-5 w-5 text-green-500" />
                <span>contact@plugzen.fr</span>
              </div>
              <div className="flex items-center space-x-2">
                <MapPin className="h-5 w-5 text-green-500" />
                <span>Chassieu, France</span>
              </div>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Liens rapides</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/services" className="text-gray-400 hover:text-green-500 transition-colors">
                  Nos Services
                </Link>
              </li>
              <li>
                <Link to="/products" className="text-gray-400 hover:text-green-500 transition-colors">
                  Nos Produits
                </Link>
              </li>
              <li>
                <Link to="/about" className="text-gray-400 hover:text-green-500 transition-colors">
                  À propos
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-gray-400 hover:text-green-500 transition-colors">
                  Contact
                </Link>
              </li>
              <li>
                <Link to="/cgv" className="text-gray-400 hover:text-green-500 transition-colors">
                  CGV
                </Link>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
          <p>&copy; {new Date().getFullYear()} PlugZen. Tous droits réservés.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;