import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Zap, Menu, X } from 'lucide-react';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <header className="fixed w-full bg-white/95 backdrop-blur-sm z-50 shadow-sm">
      <nav className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center space-x-2">
            <Zap className="h-8 w-8 text-green-600" />
            <span className="text-2xl font-bold text-gray-900">PlugZen</span>
          </Link>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <Link 
              to="/services" 
              className="text-gray-600 hover:text-green-600 transition-colors font-medium"
            >
              Services
            </Link>
            <Link 
              to="/products" 
              className="text-gray-600 hover:text-green-600 transition-colors font-medium"
            >
              Produits
            </Link>
            <Link 
              to="/about" 
              className="text-gray-600 hover:text-green-600 transition-colors font-medium"
            >
              À propos
            </Link>
            <Link 
              to="/calculateur-aides" 
              className="text-gray-600 hover:text-green-600 transition-colors font-medium"
            >
              Calculer mes aides
            </Link>
            <Link 
              to="/contact" 
              className="bg-green-600 text-white px-6 py-2 rounded-full hover:bg-green-700 transition-colors font-medium"
            >
              Demander un devis
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={toggleMenu}
            className="md:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors"
            aria-label="Toggle menu"
          >
            {isMenuOpen ? (
              <X className="h-6 w-6 text-gray-600" />
            ) : (
              <Menu className="h-6 w-6 text-gray-600" />
            )}
          </button>
        </div>

        {/* Mobile Navigation */}
        <div
          className={`md:hidden absolute left-0 right-0 top-full bg-white border-t shadow-lg transition-all duration-300 ease-in-out ${
            isMenuOpen ? 'opacity-100 visible' : 'opacity-0 invisible'
          }`}
        >
          <div className="flex flex-col p-4">
            <Link
              to="/services"
              className="text-gray-600 hover:text-green-600 transition-colors py-3 font-medium text-center"
              onClick={() => setIsMenuOpen(false)}
            >
              Services
            </Link>
            <Link
              to="/products"
              className="text-gray-600 hover:text-green-600 transition-colors py-3 font-medium text-center"
              onClick={() => setIsMenuOpen(false)}
            >
              Produits
            </Link>
            <Link
              to="/about"
              className="text-gray-600 hover:text-green-600 transition-colors py-3 font-medium text-center"
              onClick={() => setIsMenuOpen(false)}
            >
              À propos
            </Link>
            <Link
              to="/calculateur-aides"
              className="text-gray-600 hover:text-green-600 transition-colors py-3 font-medium text-center"
              onClick={() => setIsMenuOpen(false)}
            >
              Calculer mes aides
            </Link>
            <Link
              to="/contact"
              className="bg-green-600 text-white px-6 py-3 rounded-full hover:bg-green-700 transition-colors text-center font-medium mt-2"
              onClick={() => setIsMenuOpen(false)}
            >
              Demander un devis
            </Link>
          </div>
        </div>
      </nav>
    </header>
  );
};

export default Header;