import React from 'react';
import { motion } from 'framer-motion';
import { PhoneCall, ClipboardCheck, Wrench, CheckSquare, ArrowRight } from 'lucide-react';

const steps = [
  {
    icon: <PhoneCall className="h-8 w-8 text-green-600" />,
    title: "1. Premier contact",
    description: "Appelez-nous ou remplissez notre formulaire en ligne pour une première évaluation gratuite"
  },
  {
    icon: <ClipboardCheck className="h-8 w-8 text-green-600" />,
    title: "2. Étude technique",
    description: "Un expert évalue vos besoins et réalise un diagnostic technique complet"
  },
  {
    icon: <Wrench className="h-8 w-8 text-green-600" />,
    title: "3. Installation",
    description: "Nos techniciens certifiés installent votre borne en respectant toutes les normes"
  },
  {
    icon: <CheckSquare className="h-8 w-8 text-green-600" />,
    title: "4. Mise en service",
    description: "Test complet de l'installation et formation à l'utilisation de votre borne"
  }
];

const InstallationProcess = () => {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Comment ça marche ?</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Un processus simple et efficace pour l'installation de votre borne
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="relative"
            >
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-1/4 right-0 w-full h-0.5 bg-green-200" />
              )}
              
              <div className="relative bg-white p-6 rounded-xl text-center z-10">
                <div className="inline-block p-3 bg-green-100 rounded-full mb-4">
                  {step.icon}
                </div>
                <h3 className="text-xl font-semibold mb-2">{step.title}</h3>
                <p className="text-gray-600">{step.description}</p>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          className="mt-12 text-center"
        >
          <a
            href="/contact"
            className="bg-green-600 text-white px-8 py-3 rounded-full inline-flex items-center hover:bg-green-700 transition-colors"
          >
            Démarrer mon projet
            <ArrowRight className="ml-2 h-5 w-5" />
          </a>
        </motion.div>
      </div>
    </section>
  );
};

export default InstallationProcess;