import React from 'react';
import { Zap, Shield, Clock, Award } from 'lucide-react';
import { motion } from 'framer-motion';

const features = [
  {
    icon: <Zap className="h-8 w-8 text-green-600" />,
    title: "Installation rapide",
    description: "Installation professionnelle en 48h après validation du devis"
  },
  {
    icon: <Shield className="h-8 w-8 text-green-600" />,
    title: "Garantie 2 ans",
    description: "Tous nos produits et installations sont garantis"
  },
  {
    icon: <Clock className="h-8 w-8 text-green-600" />,
    title: "Support 5/7j",
    description: "Une équipe technique à votre service"
  },
  {
    icon: <Award className="h-8 w-8 text-green-600" />,
    title: "Certifié IRVE",
    description: "Installateur agréé pour la recharge de véhicule électrique"
  }
];

const Features = () => {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Pourquoi choisir PlugZen ?</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Nous vous accompagnons dans votre transition vers la mobilité électrique
            avec des solutions adaptées à vos besoins.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="text-center p-6 rounded-lg"
            >
              <div className="inline-block p-3 bg-green-100 rounded-full mb-4">
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;