import React from 'react';
import { motion } from 'framer-motion';
import { Users, Battery, Award, Timer } from 'lucide-react';

const stats = [
  {
    icon: <Timer className="h-8 w-8 text-green-600" />,
    value: "48h",
    label: "Délai d'installation"
  },
  {
    icon: <Award className="h-8 w-8 text-green-600" />,
    value: "100%",
    label: "Satisfaction client"
  },
  {
    icon: <Battery className="h-8 w-8 text-green-600" />,
    value: "2 ans",
    label: "Garantie"
  },
  {
    icon: <Users className="h-8 w-8 text-green-600" />,
    value: "5/7j",
    label: "Support client"
  }
];

const Stats = () => {
  return (
    <section className="py-20 bg-green-600">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="text-center text-white"
            >
              <div className="inline-block p-3 bg-white/10 rounded-full mb-4">
                {stat.icon}
              </div>
              <div className="text-4xl font-bold mb-2">{stat.value}</div>
              <div className="text-green-100">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Stats;