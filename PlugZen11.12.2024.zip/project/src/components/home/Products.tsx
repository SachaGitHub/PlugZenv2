import React from 'react';
import { motion } from 'framer-motion';
import { Battery, Zap, Shield, Check, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const products = [
  {
    title: "PlugZen Home 7.4",
    power: "7.4 kW",
    image: "https://m.media-amazon.com/images/I/61dijJpBW7L._AC_SY355_.jpg",
    features: [
      "Installation simple",
      "Compatible Type 2",
      "Câble de 6m intégré",
      "Garantie 2 ans"
    ],
    price: "À partir de 699€"
  },
  {
    title: "PlugZen Pro 22",
    power: "22 kW",
    image: "https://m.media-amazon.com/images/I/51N03KUKczL._AC_SY355_.jpg",
    features: [
      "Recharge rapide",
      "Usage intensif",
      "Compatible Type 2",
      "Garantie 2 ans"
    ],
    price: "À partir de 899€"
  }
];

const Products = () => {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Nos solutions de recharge</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Des bornes de recharge fiables et performantes pour tous vos besoins
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {products.map((product, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-white border rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="aspect-w-16 aspect-h-9">
                <img
                  src={product.image}
                  alt={product.title}
                  className="w-full h-48 object-contain p-4"
                />
              </div>
              
              <div className="p-6">
                <h3 className="text-2xl font-semibold mb-2">{product.title}</h3>
                <div className="flex items-center text-green-600 mb-4">
                  <Zap className="h-5 w-5 mr-2" />
                  <span>{product.power}</span>
                </div>
                
                <ul className="space-y-2 mb-6">
                  {product.features.map((feature, i) => (
                    <li key={i} className="flex items-center text-gray-600">
                      <Check className="h-5 w-5 text-green-600 mr-2" />
                      {feature}
                    </li>
                  ))}
                </ul>
                
                <div className="flex items-center justify-between">
                  <span className="text-xl font-bold">{product.price}</span>
                  <Link
                    to="/contact"
                    className="bg-green-600 text-white px-6 py-2 rounded-full hover:bg-green-700 transition-colors"
                  >
                    En savoir plus
                  </Link>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Products;