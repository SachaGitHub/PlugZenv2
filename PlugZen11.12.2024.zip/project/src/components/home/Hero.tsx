import React from 'react';
import { ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';

const Hero = () => {
  return (
    <section className="relative h-screen flex items-center">
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1593941707882-a5bba14938c7?auto=format&fit=crop&q=80"
          alt="Electric Vehicle Charging"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/50" />
      </div>
      
      <div className="container mx-auto px-4 z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-3xl text-white"
        >
          <h1 className="text-5xl md:text-6xl font-bold mb-6">
            Rechargez votre avenir avec PlugZen
          </h1>
          <p className="text-xl mb-8">
            Expert en installation de bornes de recharge pour véhicules électriques.
            Solutions sur mesure pour particuliers et professionnels.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <a
              href="/contact"
              className="bg-green-600 text-white px-8 py-3 rounded-full inline-flex items-center justify-center hover:bg-green-700 transition-colors"
            >
              Demander un devis gratuit
              <ArrowRight className="ml-2 h-5 w-5" />
            </a>
            <a
              href="/calculateur-aides"
              className="bg-white text-gray-900 px-8 py-3 rounded-full inline-flex items-center justify-center hover:bg-gray-100 transition-colors"
            >
              Calculer mes aides
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;