import React from 'react';
import { motion } from 'framer-motion';
import { Plus, Minus } from 'lucide-react';

const faqs = [
  {
    question: "Combien de temps dure l'installation d'une borne ?",
    answer: "L'installation d'une borne de recharge prend généralement entre 2 et 4 heures pour une installation standard. Nous garantissons une installation sous 48h après validation du devis."
  },
  {
    question: "Quelles sont les aides financières disponibles ?",
    answer: "Plusieurs aides sont disponibles : le crédit d'impôt de 500€, la prime ADVENIR jusqu'à 960€ pour les copropriétés, et des aides régionales spécifiques. Nous vous accompagnons dans vos démarches."
  },
  {
    question: "La borne est-elle compatible avec tous les véhicules ?",
    answer: "Oui, nos bornes sont équipées d'un connecteur Type 2, compatible avec tous les véhicules électriques commercialisés en Europe. Nous adaptons la puissance selon votre véhicule."
  },
  {
    question: "Que couvre la garantie ?",
    answer: "Notre garantie de 2 ans couvre le matériel et l'installation. Elle inclut les pièces, la main d'œuvre et le déplacement en cas de dysfonctionnement."
  },
  {
    question: "Proposez-vous un service de maintenance ?",
    answer: "Oui, nous proposons un service de maintenance préventive et curative sur rendez-vous. Notre équipe technique est disponible 5j/7 pour toute intervention."
  }
];

const FAQ = () => {
  const [openIndex, setOpenIndex] = React.useState<number | null>(null);

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold mb-4">Questions Fréquentes</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Retrouvez les réponses aux questions les plus fréquentes sur nos services d'installation de bornes de recharge.
          </p>
        </motion.div>
        
        <div className="max-w-3xl mx-auto">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="mb-4"
            >
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full flex items-center justify-between p-6 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <span className="text-lg font-semibold text-left">{faq.question}</span>
                {openIndex === index ? (
                  <Minus className="h-5 w-5 text-green-600 flex-shrink-0" />
                ) : (
                  <Plus className="h-5 w-5 text-green-600 flex-shrink-0" />
                )}
              </button>
              
              {openIndex === index && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="px-6 py-4"
                >
                  <p className="text-gray-600">{faq.answer}</p>
                </motion.div>
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FAQ;