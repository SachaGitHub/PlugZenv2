import React from 'react';
import { motion } from 'framer-motion';

const partners = [
  {
    name: "ADVENIR",
    logo: "https://www.automobile-propre.com/wp-content/uploads/2018/08/logo-advenir.jpg",
  },
  {
    name: "CITE",
    logo: "https://www.rouchenergies.fr/images/illustrations/CITE-credit-d-impot-transition-energetique-537x393-min.jpg",
  },
  {
    name: "TVA Réduite",
    logo: "https://usercontent.one/wp/www.ote-concept.fr/wp-content/uploads/2023/03/Picto_TVA_Taux_Reduit_2022-1.png?media=1679757488",
  }
];

const Partners = () => {
  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Nos Partenaires</h2>
          <p className="text-gray-600">
            Nous collaborons avec les meilleurs acteurs du secteur
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {partners.map((partner, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="flex items-center justify-center p-8 bg-white rounded-lg shadow-sm"
            >
              <img
                src={partner.logo}
                alt={partner.name}
                className="h-24 object-contain grayscale-0 transition-all"
              />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Partners;