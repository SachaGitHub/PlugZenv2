import React from 'react';
import { motion } from 'framer-motion';
import { Euro, FileText, Calculator, CheckCircle, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const subsidies = [
  {
    icon: <Euro className="h-8 w-8 text-green-600" />,
    title: "Crédit d'impôt",
    description: "Bénéficiez d'un crédit d'impôt de 500€ sur l'installation de votre borne"
  },
  {
    icon: <FileText className="h-8 w-8 text-green-600" />,
    title: "Prime ADVENIR",
    description: "Jusqu'à 960€ d'aide pour les copropriétés et entreprises"
  },
  {
    icon: <Calculator className="h-8 w-8 text-green-600" />,
    title: "TVA Réduite",
    description: "TVA à 5,5% sur l'installation pour les logements de plus de 2 ans"
  },
  {
    icon: <CheckCircle className="h-8 w-8 text-green-600" />,
    title: "Aides locales",
    description: "Des subventions supplémentaires selon votre région"
  }
];

const Subsidies = () => {
  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Aides financières</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Profitez des différentes aides de l'État pour financer votre installation
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {subsidies.map((subsidy, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-white p-6 rounded-xl shadow-sm"
            >
              <div className="inline-block p-3 bg-green-100 rounded-full mb-4">
                {subsidy.icon}
              </div>
              <h3 className="text-xl font-semibold mb-2">{subsidy.title}</h3>
              <p className="text-gray-600">{subsidy.description}</p>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          className="mt-12 text-center"
        >
          <Link
            to="/calculateur-aides"
            className="inline-flex items-center text-green-600 hover:text-green-700 font-medium"
          >
            Calculez vos aides
            <ArrowRight className="ml-2 h-5 w-5" />
          </Link>
        </motion.div>
      </div>
    </section>
  );
};

export default Subsidies;