import React from 'react';
import { Calculator } from 'lucide-react';
import { REGIONS, BORNE_PRICES } from '../../utils/constants';
import type { SubsidyFormData } from '../../types/subsidies';

interface SubsidyFormProps {
  formData: SubsidyFormData;
  onChange: (e: React.ChangeEvent<HTMLSelectElement | HTMLInputElement>) => void;
  onSubmit: (e: React.FormEvent) => void;
}

const SubsidyForm: React.FC<SubsidyFormProps> = ({ formData, onChange, onSubmit }) => {
  return (
    <form onSubmit={onSubmit} className="space-y-6">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Type d'installation
        </label>
        <select
          name="installationType"
          value={formData.installationType}
          onChange={onChange}
          className="w-full border-gray-300 rounded-lg shadow-sm"
          required
        >
          <option value="">Sélectionnez le type d'installation</option>
          <option value="individuel">Maison individuelle</option>
          <option value="copropriete">Copropriété</option>
          <option value="entreprise">Entreprise</option>
        </select>
      </div>

      {formData.installationType === 'entreprise' && (
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Type de parking
          </label>
          <select
            name="parkingType"
            value={formData.parkingType}
            onChange={onChange}
            className="w-full border-gray-300 rounded-lg shadow-sm"
            required
          >
            <option value="">Sélectionnez le type de parking</option>
            <option value="private">Réservé à la flotte ou aux salariés</option>
            <option value="public">Ouvert au public</option>
          </select>
        </div>
      )}

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Région
        </label>
        <select
          name="region"
          value={formData.region}
          onChange={onChange}
          className="w-full border-gray-300 rounded-lg shadow-sm"
          required
        >
          <option value="">Sélectionnez votre région</option>
          {REGIONS.map(region => (
            <option key={region} value={region}>{region}</option>
          ))}
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Modèle de borne
        </label>
        <select
          name="borneModel"
          value={formData.borneModel}
          onChange={onChange}
          className="w-full border-gray-300 rounded-lg shadow-sm"
          required
        >
          <option value="">Sélectionnez un modèle</option>
          {Object.entries(BORNE_PRICES).map(([model, price]) => (
            <option key={model} value={model}>{model} - {price}€ HT</option>
          ))}
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Nombre de bornes
        </label>
        <input
          type="number"
          name="quantity"
          value={formData.quantity}
          onChange={onChange}
          min="1"
          max="100"
          className="w-full border-gray-300 rounded-lg shadow-sm"
          required
        />
      </div>

      <div className="pt-4">
        <button
          type="submit"
          className="w-full bg-green-600 text-white py-3 rounded-lg hover:bg-green-700 transition-colors flex items-center justify-center"
        >
          <Calculator className="h-5 w-5 mr-2" />
          Calculer mes aides
        </button>
      </div>
    </form>
  );
};

export default SubsidyForm;