import React from 'react';
import { motion } from 'framer-motion';
import { Wrench, Truck, Euro, Home, Calculator } from 'lucide-react';
import type { SubsidyResult } from '../../types/subsidies';

interface SubsidyResultsProps {
  result: SubsidyResult;
}

const SubsidyResults: React.FC<SubsidyResultsProps> = ({ result }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="mt-8 pt-8 border-t"
    >
      <h2 className="text-xl font-semibold mb-4">Estimation de vos aides</h2>
      <div className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          <div className="p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center mb-2">
              <Wrench className="h-5 w-5 text-green-600 mr-2" />
              <span className="font-medium">Prix des bornes (HT)</span>
            </div>
            <span className="text-lg font-semibold">{result.borneCost.toFixed(2)}€</span>
          </div>
          <div className="p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center mb-2">
              <Truck className="h-5 w-5 text-green-600 mr-2" />
              <span className="font-medium">Déplacement + Main d'œuvre</span>
            </div>
            <span className="text-lg font-semibold">{result.installationCost.toFixed(2)}€</span>
          </div>
        </div>

        {!result.isBusiness && !result.isCondo && (
          <div className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center">
              <Euro className="h-5 w-5 text-green-600 mr-2" />
              <span>Crédit d'impôt</span>
            </div>
            <span className="font-semibold">{result.creditImpot.toFixed(2)}€</span>
          </div>
        )}
        
        <div className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
          <div className="flex items-center">
            <Home className="h-5 w-5 text-green-600 mr-2" />
            <span>Prime ADVENIR</span>
          </div>
          <span className="font-semibold">{result.primeAdvenir.toFixed(2)}€</span>
        </div>

        <div className="flex justify-between items-center p-4 bg-green-100 rounded-lg">
          <div className="flex items-center">
            <Calculator className="h-5 w-5 text-green-600 mr-2" />
            <span className="font-semibold">Total des aides</span>
          </div>
          <span className="font-bold text-xl">{result.total.toFixed(2)}€</span>
        </div>

        <div className="mt-6 space-y-4">
          <div className="flex justify-between items-center p-4 bg-gray-100 rounded-lg">
            <span className="font-medium">Total HT</span>
            <span className="font-semibold">{result.totalHT.toFixed(2)}€</span>
          </div>
          <div className="flex justify-between items-center p-4 bg-gray-100 rounded-lg">
            <span className="font-medium">TVA ({result.isBusiness ? '20%' : '5.5%'})</span>
            <span className="font-semibold">{result.tva.toFixed(2)}€</span>
          </div>
          <div className="flex justify-between items-center p-4 bg-gray-800 text-white rounded-lg">
            <span className="font-medium">Total TTC</span>
            <span className="font-bold text-xl">{result.totalTTC.toFixed(2)}€</span>
          </div>
        </div>

        <div className="mt-6 p-4 bg-blue-50 rounded-lg text-sm text-blue-800">
          <p className="font-medium mb-2">Informations importantes :</p>
          <ul className="list-disc list-inside space-y-1">
            {!result.isBusiness ? (
              <>
                {!result.isCondo && (
                  <li>Le crédit d'impôt de 500€ par borne est remboursé l'année suivante</li>
                )}
                <li>La TVA est appliquée au taux réduit de 5.5%</li>
              </>
            ) : (
              <>
                <li>La TVA est appliquée au taux normal de 20% et est récupérable</li>
                <li>Les entreprises peuvent amortir l'investissement</li>
              </>
            )}
            <li>La prime ADVENIR nécessite un installateur qualifié IRVE</li>
            <li>Ces montants sont donnés à titre indicatif</li>
          </ul>
        </div>
      </div>
    </motion.div>
  );
};

export default SubsidyResults;