import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Calculator } from 'lucide-react';
import SubsidyForm from '../components/subsidies/SubsidyForm';
import SubsidyResults from '../components/subsidies/SubsidyResults';
import { calculateSubsidies } from '../utils/subsidyCalculator';
import type { SubsidyFormData, SubsidyResult } from '../types/subsidies';

const SubsidiesCalculator: React.FC = () => {
  const [formData, setFormData] = useState<SubsidyFormData>({
    installationType: '',
    parkingType: '',
    region: '',
    borneModel: '',
    quantity: '1'
  });

  const [result, setResult] = useState<SubsidyResult | null>(null);

  const handleChange = (e: React.ChangeEvent<HTMLSelectElement | HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const calculatedResult = calculateSubsidies(formData);
    setResult(calculatedResult);
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-20">
      <div className="container mx-auto px-4 py-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-3xl mx-auto"
        >
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold mb-4">Calculez vos aides</h1>
            <p className="text-gray-600">
              Estimez les aides financières auxquelles vous pouvez prétendre pour l'installation
              de votre borne de recharge.
            </p>
          </div>

          <div className="bg-white rounded-2xl shadow-lg p-8">
            <SubsidyForm
              formData={formData}
              onChange={handleChange}
              onSubmit={handleSubmit}
            />
            {result && <SubsidyResults result={result} />}
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default SubsidiesCalculator;