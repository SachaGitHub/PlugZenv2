import React from 'react';
import { motion } from 'framer-motion';

const CGV = () => {
  return (
    <div className="min-h-screen bg-gray-50 pt-20">
      <div className="container mx-auto px-4 py-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-4xl mx-auto bg-white rounded-2xl shadow-lg p-8"
        >
          <h1 className="text-3xl font-bold mb-8">Conditions Générales de Vente</h1>
          
          <div className="space-y-8">
            <section>
              <h2 className="text-xl font-semibold mb-4">Article 1 - Informations légales</h2>
              <p className="text-gray-600 mb-4">
                MAXELEC SERVICES SAS<br />
                24 RUE DENIS PAPIN<br />
                69680 CHASSIEU<br />
                SIREN : 937 774 255<br />
                SIRET : 937 774 255 00015<br />
                N° TVA Intracommunautaire : FR58 937 774 255<br />
                Activité principale : Travaux d'installation électrique dans tous locaux<br />
                Forme juridique : SAS, société par actions simplifiée<br />
                Date de création : 01/01/2025
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-4">Article 2 - Application des conditions</h2>
              <p className="text-gray-600 mb-4">
                Les présentes Conditions Générales de Vente (CGV) régissent les relations entre MAXELEC SERVICES et ses clients. Toute commande implique l'acceptation sans réserve par le client des présentes conditions.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-4">Article 3 - Prestations</h2>
              <p className="text-gray-600 mb-4">
                MAXELEC SERVICES propose des services d'installation, de maintenance et de dépannage de bornes de recharge pour véhicules électriques. Nos prestations sont conformes aux normes NF C 15-100 et IEC 61851-1.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-4">Article 4 - Prix et paiement</h2>
              <p className="text-gray-600 mb-4">
                Les prix sont indiqués en euros HT (hors taxes). La TVA applicable sera ajoutée au taux en vigueur au jour de la facturation. Le paiement intégral est exigé avant le début des travaux d'installation. Aucune installation ne sera effectuée sans la réception préalable du paiement complet.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-4">Article 5 - Garantie</h2>
              <p className="text-gray-600 mb-4">
                Nos installations sont garanties 2 ans pièces et main d'œuvre, conformément à la législation en vigueur. Cette garantie couvre les défauts de fabrication et d'installation.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-4">Article 6 - Délai de rétractation</h2>
              <p className="text-gray-600 mb-4">
                Conformément à l'article L221-18 du Code de la consommation, le client dispose d'un délai de 14 jours pour exercer son droit de rétractation. Ce délai court à compter de la conclusion du contrat.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-4">Article 7 - Protection des données</h2>
              <p className="text-gray-600 mb-4">
                Conformément au RGPD, les clients disposent d'un droit d'accès, de rectification et de suppression de leurs données personnelles. Ces données sont utilisées uniquement dans le cadre de la relation commerciale.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-4">Article 8 - Litiges</h2>
              <p className="text-gray-600 mb-4">
                En cas de litige, une solution amiable sera recherchée. À défaut, le tribunal de commerce de Lyon sera seul compétent. Le droit français est applicable.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-4">Article 9 - Assurance</h2>
              <p className="text-gray-600 mb-4">
                MAXELEC SERVICES est assuré pour sa responsabilité civile professionnelle auprès de AXA Assurances (Police n° 1234567890) pour l'ensemble de ses activités.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-4">Article 10 - Médiation</h2>
              <p className="text-gray-600 mb-4">
                Conformément à l'article L612-1 du Code de la consommation, vous pouvez recourir gratuitement au service de médiation MEDICYS dont nous relevons : par voie électronique : www.medicys.fr, ou par voie postale : MEDICYS - 73 Boulevard de Clichy - 75009 Paris
              </p>
            </section>
          </div>

          <div className="mt-8 text-sm text-gray-500">
            <p>Dernière mise à jour : {new Date().toLocaleDateString()}</p>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default CGV;