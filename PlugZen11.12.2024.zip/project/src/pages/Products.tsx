import React from 'react';
import { motion } from 'framer-motion';
import { Zap, Shield, Clock, Settings, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const products = [
  {
    name: "PlugZen Home 7.4",
    image: "https://m.media-amazon.com/images/I/61dijJpBW7L._AC_SY355_.jpg",
    price: "699€",
    power: "7.4 kW",
    features: [
      "Installation simple et rapide",
      "Compatible Type 2",
      "Câble de 6m intégré",
      "Garantie 2 ans"
    ],
    specs: {
      power: "Monophasé 7.4 kW",
      connection: "Type 2",
      amperage: "32 A",
      cable: "6 mètres",
      tension: "240V",
      protection: "IP54",
      montage: "Mural",
      couleur: "Noir"
    }
  },
  {
    name: "PlugZen Pro 11",
    image: "https://m.media-amazon.com/images/I/61g1h7BYJmL._AC_SY355_.jpg",
    price: "799€",
    power: "11 kW",
    features: [
      "Recharge optimisée",
      "Usage régulier",
      "Compatible Type 2",
      "Garantie 2 ans"
    ],
    specs: {
      power: "Triphasé 11 kW",
      connection: "Type 2",
      amperage: "32 A",
      cable: "6 mètres",
      tension: "240V",
      protection: "IP54",
      montage: "Mural",
      couleur: "Noir"
    }
  },
  {
    name: "PlugZen Pro 22",
    image: "https://m.media-amazon.com/images/I/51N03KUKczL._AC_SY355_.jpg",
    price: "899€",
    power: "22 kW",
    features: [
      "Recharge ultra-rapide",
      "Usage intensif",
      "Compatible Type 2",
      "Garantie 2 ans"
    ],
    specs: {
      power: "Triphasé 22 kW",
      connection: "Type 2",
      amperage: "32 A",
      cable: "6 mètres",
      tension: "240V",
      protection: "IP54",
      montage: "Mural",
      couleur: "Noir"
    }
  }
];

const Products = () => {
  return (
    <div className="min-h-screen bg-gray-50 pt-20">
      <div className="container mx-auto px-4 py-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl font-bold mb-4">Nos Solutions de Recharge</h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Des bornes de recharge fiables et performantes pour tous vos besoins
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {products.map((product, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.2 }}
              className="bg-white rounded-2xl shadow-lg overflow-hidden flex flex-col h-full"
            >
              <div className="h-64 p-4 flex items-center justify-center">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-contain"
                />
              </div>
              
              <div className="p-8 flex-grow flex flex-col">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-2xl font-bold">{product.name}</h2>
                  <div className="flex items-center text-green-600">
                    <Zap className="h-5 w-5 mr-1" />
                    <span className="font-semibold">{product.power}</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-6 mb-6 flex-grow">
                  <div>
                    <h3 className="text-lg font-semibold mb-3">Caractéristiques</h3>
                    <ul className="space-y-2">
                      {product.features.map((feature, i) => (
                        <li key={i} className="flex items-center text-gray-600">
                          <Shield className="h-4 w-4 text-green-600 mr-2 flex-shrink-0" />
                          <span className="text-sm">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold mb-3">Spécifications techniques</h3>
                    <ul className="space-y-2">
                      {Object.entries(product.specs).map(([key, value]) => (
                        <li key={key} className="text-sm text-gray-600">
                          <span className="font-medium capitalize">{key}: </span>
                          {value}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-6 border-t mt-auto">
                  <div className="text-2xl font-bold text-gray-900">
                    À partir de {product.price}
                  </div>
                  <Link
                    to="/contact"
                    className="inline-flex items-center px-6 py-3 bg-green-600 text-white rounded-full hover:bg-green-700 transition-colors"
                  >
                    Demander un devis
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          className="mt-16 text-center bg-green-50 p-8 rounded-2xl"
        >
          <h2 className="text-2xl font-bold mb-4">Besoin d'aide pour choisir ?</h2>
          <p className="text-gray-600 mb-6">
            Nos experts sont là pour vous guider dans le choix de votre borne de recharge.
          </p>
          <Link
            to="/contact"
            className="inline-flex items-center px-8 py-3 bg-green-600 text-white rounded-full hover:bg-green-700 transition-colors"
          >
            Contactez-nous
            <ArrowRight className="ml-2 h-5 w-5" />
          </Link>
        </motion.div>
      </div>
    </div>
  );
};

export default Products;