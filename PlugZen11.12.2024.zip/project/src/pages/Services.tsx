import React from 'react';
import { motion } from 'framer-motion';
import { Home, Building2, Wrench, Shield, Clock, Users, Battery, Tool } from 'lucide-react';
import { Link } from 'react-router-dom';

const services = [
  {
    icon: <Home className="h-12 w-12 text-green-600" />,
    title: "Installation Résidentielle",
    description: "Installation de bornes de recharge pour maisons individuelles",
    features: [
      "Étude technique personnalisée",
      "Installation sous 48h",
      "Garantie 5 ans",
      "Maintenance préventive"
    ],
    price: "À partir de 990€"
  },
  {
    icon: <Building2 className="h-12 w-12 text-green-600" />,
    title: "Solutions Copropriétés",
    description: "Équipement complet pour parkings collectifs",
    features: [
      "Étude de faisabilité gratuite",
      "Installation évolutive",
      "Système de facturation intégré",
      "Maintenance 24/7"
    ],
    price: "Sur devis"
  },
  {
    icon: <Battery className="h-12 w-12 text-green-600" />,
    title: "Solutions Entreprises",
    description: "Bornes de recharge pour flottes professionnelles",
    features: [
      "Analyse des besoins",
      "Installation sur mesure",
      "Supervision à distance",
      "Support dédié"
    ],
    price: "Sur devis"
  }
];

const additionalServices = [
  {
    icon: <Wrench className="h-6 w-6 text-green-600" />,
    title: "Maintenance",
    description: "Service de maintenance préventive et curative pour garantir la disponibilité de vos bornes"
  },
  {
    icon: <Shield className="h-6 w-6 text-green-600" />,
    title: "Garantie",
    description: "Garantie complète de 5 ans sur l'installation et le matériel"
  },
  {
    icon: <Clock className="h-6 w-6 text-green-600" />,
    title: "Support 24/7",
    description: "Assistance technique disponible 24h/24 et 7j/7"
  },
  {
    icon: <Users className="h-6 w-6 text-green-600" />,
    title: "Formation",
    description: "Formation des utilisateurs à l'utilisation optimale des bornes"
  }
];

const Services = () => {
  return (
    <div className="min-h-screen bg-gray-50 pt-20">
      {/* Hero Section */}
      <section className="bg-white py-20">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center max-w-3xl mx-auto"
          >
            <h1 className="text-4xl font-bold mb-6">Nos Services</h1>
            <p className="text-xl text-gray-600">
              Des solutions de recharge adaptées à tous vos besoins, avec un accompagnement personnalisé
              de A à Z.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Main Services */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-2xl shadow-lg overflow-hidden"
              >
                <div className="p-8">
                  <div className="flex justify-center mb-6">
                    <div className="p-3 bg-green-100 rounded-full">
                      {service.icon}
                    </div>
                  </div>
                  <h3 className="text-2xl font-bold text-center mb-4">{service.title}</h3>
                  <p className="text-gray-600 text-center mb-6">{service.description}</p>
                  <ul className="space-y-3 mb-6">
                    {service.features.map((feature, i) => (
                      <li key={i} className="flex items-center text-gray-600">
                        <Shield className="h-5 w-5 text-green-600 mr-2" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-gray-900 mb-4">
                      {service.price}
                    </div>
                    <Link
                      to="/contact"
                      className="inline-block px-8 py-3 bg-green-600 text-white rounded-full hover:bg-green-700 transition-colors"
                    >
                      Demander un devis
                    </Link>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Additional Services */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-16">Services Complémentaires</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {additionalServices.map((service, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-gray-50 p-6 rounded-xl"
              >
                <div className="inline-block p-3 bg-green-100 rounded-full mb-4">
                  {service.icon}
                </div>
                <h3 className="text-xl font-semibold mb-2">{service.title}</h3>
                <p className="text-gray-600">{service.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-green-600">
        <div className="container mx-auto px-4">
          <div className="text-center text-white">
            <h2 className="text-3xl font-bold mb-4">Prêt à passer à l'électrique ?</h2>
            <p className="text-xl mb-8">
              Nos experts sont là pour vous accompagner dans votre projet
            </p>
            <Link
              to="/contact"
              className="inline-block px-8 py-3 bg-white text-green-600 rounded-full hover:bg-gray-100 transition-colors"
            >
              Contactez-nous
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;