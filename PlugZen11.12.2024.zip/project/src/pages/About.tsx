import React from 'react';
import { motion } from 'framer-motion';
import { Shield, Award, Users, Clock, Zap, Leaf, Settings, HandshakeIcon } from 'lucide-react';

const reasons = [
  {
    icon: <Shield className="h-8 w-8 text-green-600" />,
    title: "Expertise Certifiée",
    description: "Nos techniciens sont certifiés IRVE et formés aux dernières technologies de recharge électrique."
  },
  {
    icon: <Award className="h-8 w-8 text-green-600" />,
    title: "Qualité Garantie",
    description: "Tous nos produits et installations sont garantis 2 ans, avec un service après-vente réactif."
  },
  {
    icon: <Users className="h-8 w-8 text-green-600" />,
    title: "Service Personnalisé",
    description: "Nous vous accompagnons de A à Z dans votre projet, avec des solutions adaptées à vos besoins."
  },
  {
    icon: <Clock className="h-8 w-8 text-green-600" />,
    title: "Réactivité",
    description: "Installation sous 48h après validation du devis, intervention rapide en cas de besoin."
  }
];

const values = [
  {
    icon: <Zap className="h-8 w-8 text-white" />,
    title: "Innovation",
    description: "Nous utilisons les dernières technologies pour vous offrir le meilleur service."
  },
  {
    icon: <Leaf className="h-8 w-8 text-white" />,
    title: "Écologie",
    description: "Nous contribuons activement à la transition énergétique."
  },
  {
    icon: <Settings className="h-8 w-8 text-white" />,
    title: "Excellence",
    description: "Nous visons l'excellence dans chacune de nos installations."
  },
  {
    icon: <HandshakeIcon className="h-8 w-8 text-white" />,
    title: "Engagement",
    description: "Nous nous engageons à vos côtés pour votre satisfaction."
  }
];

const About = () => {
  return (
    <div className="min-h-screen bg-gray-50 pt-20">
      {/* Hero Section */}
      <section className="bg-white py-20">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center max-w-3xl mx-auto"
          >
            <h1 className="text-4xl font-bold mb-6">Pourquoi Choisir PlugZen ?</h1>
            <p className="text-xl text-gray-600">
              Expert en solutions de recharge pour véhicules électriques, nous mettons notre savoir-faire
              à votre service pour une transition énergétique réussie.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Reasons Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {reasons.map((reason, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white p-6 rounded-xl shadow-sm"
              >
                <div className="inline-block p-3 bg-green-100 rounded-full mb-4">
                  {reason.icon}
                </div>
                <h3 className="text-xl font-semibold mb-2">{reason.title}</h3>
                <p className="text-gray-600">{reason.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="bg-green-600 py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-white mb-4">Nos Valeurs</h2>
            <p className="text-green-100 max-w-2xl mx-auto">
              Des valeurs fortes qui guident chacune de nos actions
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="text-center"
              >
                <div className="inline-block p-3 bg-white/10 rounded-full mb-4">
                  {value.icon}
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">{value.title}</h3>
                <p className="text-green-100">{value.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { value: "48h", label: "Installation" },
              { value: "100%", label: "Satisfaction" },
              { value: "2 ans", label: "Garantie" },
              { value: "5/7j", label: "Support" }
            ].map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.5 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1 }}
                className="text-center"
              >
                <div className="text-4xl font-bold text-green-600 mb-2">{stat.value}</div>
                <div className="text-gray-600">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;