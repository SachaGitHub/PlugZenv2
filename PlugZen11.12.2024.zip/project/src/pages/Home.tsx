import React from 'react';
import Hero from '../components/home/Hero';
import Features from '../components/home/Features';
import Products from '../components/home/Products';
import InstallationProcess from '../components/home/InstallationProcess';
import Subsidies from '../components/home/Subsidies';
import Stats from '../components/home/Stats';
import Testimonials from '../components/home/Testimonials';
import Partners from '../components/home/Partners';
import FAQ from '../components/home/FAQ';
import ContactForm from '../components/home/ContactForm';

const Home = () => {
  return (
    <div>
      <Hero />
      <Features />
      <Products />
      <InstallationProcess />
      <Subsidies />
      <Stats />
      <Testimonials />
      <Partners />
      <FAQ />
      <ContactForm />
    </div>
  );
};

export default Home;