export interface SubsidyFormData {
  installationType: string;
  parkingType: string;
  region: string;
  borneModel: string;
  quantity: string;
}

export interface SubsidyResult {
  creditImpot: number;
  primeAdvenir: number;
  tvaReduite: number;
  total: number;
  totalHT: number;
  totalTTC: number;
  installationCost: number;
  borneCost: number;
  isBusiness: boolean;
  isCondo: boolean;
  tva: number;
}