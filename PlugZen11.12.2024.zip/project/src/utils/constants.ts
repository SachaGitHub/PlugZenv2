// ... (previous constants)

export const BORNE_PRICES = {
  'PlugZen Home 7.4': 699,
  'PlugZen Pro 11': 799,
  'PlugZen Pro 22': 899
} as const;

export const INSTALLATION_COSTS = {
  TRAVEL: 300,
  LABOR_PER_UNIT: 200
} as const;

export const REGIONS = [
  'Auvergne-Rhône-Alpes',
  'Bourgogne-Franche-Comté',
  'Bretagne',
  'Centre-Val de Loire',
  'Corse',
  'Grand Est',
  'Hauts-de-France',
  'Île-de-France',
  'Normandie',
  'Nouvelle-Aquitaine',
  'Occitanie',
  'Pays de la Loire',
  'Provence-Alpes-Côte d\'Azur'
] as const;