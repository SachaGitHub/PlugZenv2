const API_BASE_URL = 'http://localhost/api';

export const submitContactForm = async (formData: any) => {
  try {
    const response = await fetch(`${API_BASE_URL}/submit_contact.php`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(formData),
    });
    
    const data = await response.json();
    
    if (!response.ok) {
      throw new Error(data.error || 'Something went wrong');
    }
    
    return data;
  } catch (error) {
    console.error('Error submitting contact form:', error);
    throw error;
  }
};

export const submitQuoteRequest = async (formData: any) => {
  try {
    const response = await fetch(`${API_BASE_URL}/submit_quote.php`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(formData),
    });
    
    const data = await response.json();
    
    if (!response.ok) {
      throw new Error(data.error || 'Something went wrong');
    }
    
    return data;
  } catch (error) {
    console.error('Error submitting quote request:', error);
    throw error;
  }
};