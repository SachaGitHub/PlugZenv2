import { BORNE_PRICES, INSTALLATION_COSTS } from './constants';
import type { SubsidyFormData, SubsidyResult } from '../types/subsidies';

export const calculateSubsidies = (formData: SubsidyFormData): SubsidyResult => {
  const quantity = Number(formData.quantity);
  const bornePriceHT = BORNE_PRICES[formData.borneModel as keyof typeof BORNE_PRICES] * quantity;
  const laborCost = INSTALLATION_COSTS.LABOR_PER_UNIT * quantity;
  const installationCost = INSTALLATION_COSTS.TRAVEL + laborCost;
  const totalHT = bornePriceHT + installationCost;
  
  const isBusiness = formData.installationType === 'entreprise';
  const isCondo = formData.installationType === 'copropriete';

  // Calcul TVA
  let tva;
  if (isBusiness) {
    // TVA 20% pour les entreprises
    tva = totalHT * 0.20;
  } else {
    // TVA 5.5% pour les particuliers et copropriétés
    tva = totalHT * 0.055;
  }

  const totalTTC = totalHT + tva;

  let creditImpot = 0;
  let primeAdvenir = 0;
  let tvaReduite = 0;

  // Crédit d'impôt uniquement pour les particuliers
  if (!isBusiness && !isCondo) {
    creditImpot = Math.min(500 * quantity, totalTTC * 0.75);
  }

  // Prime ADVENIR
  if (isCondo) {
    primeAdvenir = Math.min(totalTTC * 0.5, 600 * quantity);
    if (formData.region === 'Corse') {
      primeAdvenir += 300 * quantity;
    }
  } else if (isBusiness) {
    if (formData.parkingType === 'private') {
      primeAdvenir = Math.min(totalTTC * 0.2, 600 * quantity);
    } else {
      primeAdvenir = Math.min(totalTTC * 0.3, 2700 * quantity);
    }
  }

  // Économie TVA (différence entre 20% et 5.5%) pour les particuliers uniquement
  if (!isBusiness && !isCondo) {
    const tvaStandard = totalHT * 0.20;
    tvaReduite = tvaStandard - tva;
  }

  // Total des aides : crédit d'impôt + prime ADVENIR
  const total = creditImpot + primeAdvenir;

  return {
    creditImpot,
    primeAdvenir,
    tvaReduite,
    total,
    totalHT,
    totalTTC,
    installationCost,
    borneCost: bornePriceHT,
    isBusiness,
    isCondo,
    tva
  };
};